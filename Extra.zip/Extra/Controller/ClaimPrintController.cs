﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using POT.DAL;
using POT.Services;
using HSG.Helper;

namespace CPM.Controllers
{
    //[CompressFilter] - don't use it here
    [IsAuthorize(IsAuthorizeAttribute.Rights.NONE)]//Special case for some dirty session-abandoned pages and hacks
    public partial class POController : BaseController
    {
        #region Actions for PO (Secured)
        
        [AccessPO("POID")]
        [CacheControl(HttpCacheability.NoCache), HttpGet]
        public ActionResult Print(int POID)
        {
            POInternalPrint printView = new POInternalPrint();

            List<POComment> comments = new List<POComment>();
            List<POFile> filesH = new List<POFile>();
            List<PODetail> items = new List<PODetail>();

            #region Fetch PO data and set Viewstate
            vw_PO_Master_User_Loc vw = new POService().GetPOByIdForPrint(POID,
                ref comments, ref filesH, ref items, !_Session.IsOnlyCustomer);
            //Set data in View
            ViewData["comments"] = comments;
            ViewData["filesH"] = filesH;
            ViewData["items"] = items;

            printView.view = vw;
            printView.comments = comments;
            printView.filesH = filesH;
            printView.items = items;
            #endregion

            //Log Activity
            new ActivityLogService(ActivityLogService.Activity.POPrint).
                Add(new ActivityHistory() { POID = POID, PONumber = vw.PONo.ToString() });

            #region Return view based on user type

            if (_Session.IsOnlyCustomer) return View("PrintCustomer", printView); //return View("NoAccess");
            else if (_Session.IsOnlyVendor) return View("PrintVendor", printView);
            else if (_Session.IsInternal) return View("PrintInternal", printView); // View(vw);
            else return View(vw);

            #endregion
        }

        /*[AccessPO("POID")]
        [CacheControl(HttpCacheability.NoCache), HttpGet]
        public ActionResult PrintPDF(int POID)
        {

            POInternalPrint printView = new POInternalPrint();

            List<Comment> comments = new List<Comment>();
            List<FileHeader> filesH = new List<FileHeader>();
            List<PODetail> items = new List<PODetail>();

            #region Fetch PO data and set Viewstate
            vw_PO_Master_User_Loc vw = new POService().GetPOByIdForPrint(POID,
                ref comments, ref filesH, ref items, !_Session.IsOnlyCustomer);
            //Set data in View
            ViewData["comments"] = comments;
            ViewData["filesH"] = filesH;
            ViewData["items"] = items;

            printView.view = vw;
            printView.comments = comments;
            printView.filesH = filesH;
            printView.items = items;
            #endregion

            //Log Activity
            new ActivityLogService(ActivityLogService.Activity.POPrint).
                Add(new ActivityHistory() { POID = POID, PONumber = vw.PONo.ToString() });

            #region Return view based on user type
            
            //if (_Session.IsOnlyCustomer) return View("PrintCustomer", vw); //return View("NoAccess");
            //else if (_Session.IsOnlyVendor) return View("PrintVendor", vw);
            //else if (_Session.IsInternal) return View("PrintInternal", vw); // View(vw);
            //else return View(vw);
            
            #endregion

            //return this.ViewPdf("PO details", "PrintCustomer", "PrintVendor", printView, printView);
            string GUID = printView.view.ID.ToString();

            return new StandardPdfRenderer().BinaryPdfData(this,"POPrint" + GUID, "PrintInternal", printView);
        }*/
        

        #endregion 
    }
}
